
//收藏
function addFavorite2() {
    var url = window.location;
    var title = document.title;
    var ua = navigator.userAgent.toLowerCase();
    if (ua.indexOf("360se") > -1) {
        alert("由于360浏览器功能限制，请按 Ctrl+D 手动收藏！");
    }
    else if (ua.indexOf("msie 8") > -1) {
        window.external.AddToFavoritesBar(url, title); //IE8
    }
    else if (document.all) {
        try{
            window.external.addFavorite(url, title);
        }catch(e){
            alert('您的浏览器不支持,请按 Ctrl+D 手动收藏!');
        }
    }
    else if (window.sidebar) {
        window.sidebar.addPanel(title, url, "");
    }
    else {
        alert('您的浏览器不支持,请按 Ctrl+D 手动收藏!');
    }
}
//顶部右侧鼠标经过
$(document).ready(function(){
    $(".myOrder").mouseover(function(){
        $(".subNav").show();
        $(" .myOrder i").addClass("top_point");        　　
    }).mouseout(function(){
        $(".subNav").hide();
        $(".myOrder i").removeClass("top_point");
    });

    $(".help").mouseover(function(){
        $(".helpCenter").show();
        $(".help i").addClass("top_point");
        $(".myOrder i").removeClass("top_point");
    }).mouseout(function(){
        $(".helpCenter").hide();
        $("i").removeClass("top_point");
    })
    $(".attention").mouseover(function(){
        $(".attentionUs").show();
        $(".attention i").addClass("top_point");
        $(".myOrder i,.help i").removeClass("top_point");
    }).mouseout(function(){
        $(".attentionUs").hide();
        $("i").removeClass("top_point");
    })

});

//二维码点击
$(document).ready(function(){
    $(".code").click(function(){
        $("#destoonCode").show();
    });
    $(".guanBi").click(function(){
        $("#destoonCode").hide();
    });
})










//搜索框点击
$(document).ready(function(){
    $(".searchInContainer").click(function(){
        $(this).val("");
    })
})


//搜索框点击
$(document).ready(function(){
     $(".allPr").mouseover(function(){
         var index=$(this).index();
         $(this).addClass("allProductBox").siblings().removeClass("allProductBox");
         $(".box").show();
     }).mouseout(function(){
         $(this).removeClass("allProductBox");
         $(".box").hide();
     });
    $(".allPr2").mouseover(function(){
        var index=$(this).index();
        $(this).addClass("allProductBox").siblings().removeClass("allProductBox");
        $(".box1").show();
    }).mouseout(function(){
        $(this).removeClass("allProductBox");
        $(".box1").hide();
    });
    $(".allPr3").mouseover(function(){
        var index=$(this).index();
        $(this).addClass("allProductBox").siblings().removeClass("allProductBox");
        $(".box2").show();
    }).mouseout(function(){
        $(this).removeClass("allProductBox");
        $(".box2").hide();
    });
    $(".allPr4").mouseover(function(){
        var index=$(this).index();
        $(this).addClass("allProductBox").siblings().removeClass("allProductBox");
        $(".box3").show();
    }).mouseout(function(){
        $(this).removeClass("allProductBox");
        $(".box3").hide();
    });
    $(".allPr5").mouseover(function(){
        var index=$(this).index();
        $(this).addClass("allProductBox").siblings().removeClass("allProductBox");
        $(".box4").show();
    }).mouseout(function(){
        $(this).removeClass("allProductBox");
        $(".box4").hide();
    });
    $(".allPr6").mouseover(function(){
        var index=$(this).index();
        $(this).addClass("allProductBox").siblings().removeClass("allProductBox");
        $(".box5").show();
    }).mouseout(function(){
        $(this).removeClass("allProductBox");
        $(".box5").hide();
    });
});



//二级页面导航
$(document).ready(function(){
    $(".nav2").mousemove(function(){
        $(".allProductList2").show();
    }).mouseout(function(){
        $(".allProductList2").hide();
    });
})


//商城中心
$(document).ready(function(){
    $(".shopPrdocutList li").mouseover(function(){
        $(this).find(".shopProductHover").show();
    }).mouseout(function(){
        $(this).find(".shopProductHover").hide();
    });
    $(".contrast").click(function(){
        alert("请选择对比信息");
    });
})

$(document).ready(function(){
    $(".shopBox2").mouseover(function(){
        $(this).find(".hoverBox").show();
    }).mouseout(function(){
        $(this).find(".hoverBox").hide();
    });
 })


//商品详情
$(document).ready(function(){
    $(".qg").mouseover(function(){
        $(".diMing").show();
    }).mouseout(function(){
        $(".diMing").hide();
    })
})

$(document).ready(function(){
    $(".erMa").mouseover(function(){
        $(".erMaP").show();
    }).mouseout(function(){
        $(".erMaP").hide();
    })
})

$(document).ready(function(){
    $(".reP").mouseover(function(){
        $(this).addClass("hover2");
        $(".rmP").removeClass("hover2");
        $("#rexP").show();
        $("#rmxP").hide();
    });
    $(".rmP").mouseover(function(){
        $(this).addClass("hover2");
        $(".reP").removeClass("hover2");
        $("#rexP").hide();
        $("#rmxP").show();
    });
})

$(document).ready(function(){
    var $dian=$(".shopXiTop li");
    $dian.click(function(){
        $(this).addClass("hover2").siblings().removeClass("hover2");
        var index =$dian.index(this);
        $("div.tabContainrer > div").eq(index).show().siblings().hide();
        $("div.tabContainrer2 > div").eq(index).show().siblings().hide();
    })
})

$(document).ready(function(){
    var $dian2=$(".userPingTop li");
    $dian2.click(function(){
        $(this).addClass("hover2").siblings().removeClass("hover2");
        var index =$dian2.index(this);
        $("div.tabContainrer3 > div").eq(index).show().siblings().hide();

    })
})

$(document).ready(function(){
   $(".add2").click(function(){
       $(".shuInput").val(parseInt($(".shuInput").val())+1);

   });
    $(".plus2").click(function(){
        $(".shuInput").val(parseInt($(".shuInput").val())-1);
    })



})

//会员中心
$(document).ready(function(){
    $(".memberBig").click(function(){
        $(".samllLink").toggle();
        $(".point").toggle();

    });
    $(".memberBig2").click(function(){
        $(".samllLink2").toggle();
        $(".point2").toggle();

    });
    $(".memberBig3").click(function(){
        $(".samllLink3").toggle();
        $(".point3").toggle();

    });
    $(".memberBig4").click(function(){
        $(".samllLink4").toggle();
        $(".point4").toggle();

    });

})

$(document).ready(function(){
    $(".inPu").click(function(){
        $(this).val("");
    })
})

$(document).ready(function(){
    var $dian=$(".shopXiTop li");
    $dian.click(function(){
        $(this).addClass("hover2").siblings().removeClass("hover2");
        var index =$dian.index(this);
        $("div.tabContainrer > div").eq(index).show().siblings().hide();
        $("div.tabContainrer2 > div").eq(index).show().siblings().hide();
    })
})

$(document).ready(function(){
    var $dian2=$(".modifiyNav li");
    $dian2.click(function(){
        $(this).addClass("hover2").siblings().removeClass("hover2");
        var index =$dian2.index(this);
        $("div.tabContainrer4 > div").eq(index).show().siblings().hide();

    })
})

$(document).ready(function(){
    var $dian2=$(".saleNav li");
    $dian2.click(function(){
        $(this).addClass("hover3").siblings().removeClass("hover3");
        var index =$dian2.index(this);
        $("div.tabContainrer5 > div").eq(index).show().siblings().hide();

    })
})
$(document).ready(function(){
    $(".huiFu").click(function(){
        alert("确定要恢复菜单设置为默认吗？")

    });
  })


//商家页面
$(document).ready(function(){
    $(".searT").click(function(){
        $(this).val("");
    })
})

//购物车

$(document).ready(function(){
    $(".shan").click(function(){
        alert("确定要移除此商品吗？")

    });
})